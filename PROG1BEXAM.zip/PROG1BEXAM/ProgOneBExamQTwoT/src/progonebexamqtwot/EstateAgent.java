/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progonebexamqtwot;

/**
 *
 * @author jaido
 */
public class EstateAgent implements IEstateAgent {
    
    //implementation
    @Override
    public double calculateCommission(double propertyPrice, double agentCommission) {
        return propertyPrice * (agentCommission / 100);
    }

    //data validation
    @Override
    public boolean validateData(Data dataToValidate) {
        return !dataToValidate.agentLocation.isEmpty() &&
                !dataToValidate.agentName.isEmpty() &&
                dataToValidate.propertyPrice > 0 &&
                dataToValidate.commissionPercentage > 0;
    }
} 
    

