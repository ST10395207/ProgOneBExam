/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progonebexamqtwot;

import javax.swing.JOptionPane;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.JFrame;

/**
 *
 * @author jaido
 */
public class EstateAgentApp {
    
    //variables
    private JFrame frame;
    private JComboBox<String> locationComboBox;
    private JTextField agentNameTextField;
    private JTextField propertyPriceTextField;
    private JTextField commissionPercentageTextField;
    private JTextArea reportTextArea;

    private IEstateAgent estateAgent;

    public EstateAgentApp() {
        estateAgent = new EstateAgent();
        initialize();
    }

    //initialization
    private void initialize() {
        frame = new JFrame();
        frame.setTitle("Estate Agent Report");
        frame.setBounds(100, 100, 600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        locationComboBox = new JComboBox<>(new String[]{"Cape Town", "Durban", "Pretoria"});
        agentNameTextField = new JTextField(30);  // Increase row size
        propertyPriceTextField = new JTextField(30);  // Increase row size
        commissionPercentageTextField = new JTextField(30);  // Increase row size
        reportTextArea = new JTextArea(10, 40);
        reportTextArea.setLineWrap(true);
        reportTextArea.setWrapStyleWord(true);

        //button methods
        JButton processReportButton = new JButton("Process Report");
        processReportButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                processReport();
            }
        });

        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                clearFields();
            }
        });

        JButton saveReportButton = new JButton("Save Report");
        saveReportButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                saveReportToFile();
            }
        });

        //scaling of gui
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("Agent Location:"), gbc);
        gbc.gridx = 1;
        panel.add(locationComboBox, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        panel.add(new JLabel("Estate Agent Name:"), gbc);
        gbc.gridx = 1;
        panel.add(agentNameTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        panel.add(new JLabel("Property Price:"), gbc);
        gbc.gridx = 1;
        panel.add(propertyPriceTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        panel.add(new JLabel("Commission Percentage:"), gbc);
        gbc.gridx = 1;
        panel.add(commissionPercentageTextField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        panel.add(new JLabel("Estate Agent Report:"), gbc);
        gbc.gridx = 1;
        gbc.gridwidth = 2;
        panel.add(new JScrollPane(reportTextArea), gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.gridwidth = 1;
        panel.add(processReportButton, gbc);
        gbc.gridx = 1;
        panel.add(clearButton, gbc);
        gbc.gridx = 2;
        panel.add(saveReportButton, gbc);

        frame.getContentPane().add(panel);
        frame.setVisible(true);
    }

    //processreport method
    private void processReport() {
        String agentLocation = (String) locationComboBox.getSelectedItem();
        String agentName = agentNameTextField.getText().trim();
        String propertyPriceText = propertyPriceTextField.getText().trim();
        String commissionPercentageText = commissionPercentageTextField.getText().trim();

        try {
            double propertyPrice = Double.parseDouble(propertyPriceText);
            double commissionPercentage = Double.parseDouble(commissionPercentageText);

            Data data = new Data(agentLocation, agentName, propertyPrice, commissionPercentage);

            if (estateAgent.validateData(data)) {
                double commission = estateAgent.calculateCommission(data.propertyPrice, data.commissionPercentage);
                String report = String.format("Agent Location: %s\nAgent Name: %s\nProperty Price: R %.2f\nCommission Percentage: %.2f%%\nCommission Earned: R %.2f",
                        data.agentLocation, data.agentName, data.propertyPrice, data.commissionPercentage, commission);
                reportTextArea.setText(report);
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid data. Please check the input values.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid numeric input. Please enter valid numbers.");
        }
    }

    //clearing method
    private void clearFields() {
        locationComboBox.setSelectedIndex(0);
        agentNameTextField.setText("");
        propertyPriceTextField.setText("");
        commissionPercentageTextField.setText("");
        reportTextArea.setText("");
    }

    //save report method
    private void saveReportToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("report.txt"))) {
            writer.write(reportTextArea.getText());
            JOptionPane.showMessageDialog(frame, "Report saved to report.txt");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error saving report to file: " + e.getMessage());
        }
    }

} 