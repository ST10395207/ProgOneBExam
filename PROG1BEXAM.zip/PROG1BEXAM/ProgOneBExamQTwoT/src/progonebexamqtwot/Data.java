/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progonebexamqtwot;

/**
 *
 * @author jaido
 */
public class Data {
    
    //variables
    String agentLocation;
    String agentName;
    double propertyPrice;
    double commissionPercentage;

    //data
    public Data(String agentLocation, String agentName, double propertyPrice, double commissionPercentage) {
        this.agentLocation = agentLocation;
        this.agentName = agentName;
        this.propertyPrice = propertyPrice;
        this.commissionPercentage = commissionPercentage;
    }
}   

