/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import progonebexamqtwot.EstateAgent;
import progonebexamqtwot.IEstateAgent;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Before;
import org.junit.Test;
import progonebexamqtwot.Data;

/**
 *
 * @author jaido
 */
public class EstateAgentTest {
    
    private IEstateAgent estateAgent;
     
    public EstateAgentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        estateAgent = new EstateAgent();
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    @Test
    public void calculateCommission_CalculatedSuccessfully() {
        // Arrange
        double propertyPrice = 200000.0;
        double commissionPercentage = 5.0;

        // Act
        double commission = estateAgent.calculateCommission(propertyPrice, commissionPercentage);

        // Assert
        assertEquals(10000.0, commission, 0.01); // Use delta for double comparison
    }

    @Test
    public void calculateCommission_CalculatedUnsuccessfully() {
        // Arrange
        double propertyPrice = 200000.0;
        double commissionPercentage = -5.0; // Invalid commission percentage

        // Act
        double commission = estateAgent.calculateCommission(propertyPrice, commissionPercentage);

        // Assert
        assertEquals(0.0, commission, 0.01); // Use delta for double comparison
    }

    @Test
    public void validateData_ValidData() {
        // Arrange
        Data validData = new Data("Cape Town", "John Doe", 200000.0, 5.0);

        // Act
        boolean isValid = estateAgent.validateData(validData);

        // Assert
        assertTrue(isValid);
    }

    @Test
    public void validateData_InvalidLocation() {
        // Arrange
        Data invalidData = new Data("", "John Doe", 200000.0, 5.0);

        // Act
        boolean isValid = estateAgent.validateData(invalidData);

        // Assert
        assertFalse(isValid);
    }

    @Test
    public void validateData_InvalidName() {
        // Arrange
        Data invalidData = new Data("Cape Town", "", 200000.0, 5.0);

        // Act
        boolean isValid = estateAgent.validateData(invalidData);

        // Assert
        assertFalse(isValid);
    }

    @Test
    public void validateData_InvalidPropertyPrice() {
        // Arrange
        Data invalidData = new Data("Cape Town", "John Doe", 0.0, 5.0);

        // Act
        boolean isValid = estateAgent.validateData(invalidData);

        // Assert
        assertFalse(isValid);
    }

    @Test
    public void validateData_InvalidCommissionPercentage() {
        // Arrange
        Data invalidData = new Data("Cape Town", "John Doe", 200000.0, -5.0);

        // Act
        boolean isValid = estateAgent.validateData(invalidData);

        // Assert
        assertFalse(isValid);
    }
} 



