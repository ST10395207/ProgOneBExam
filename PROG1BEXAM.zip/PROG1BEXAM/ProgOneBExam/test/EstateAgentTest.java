/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import progonebexam.EstateAgent;
import progonebexam.IEstateAgent;

/**
 *
 * @author jaido
 */
public class EstateAgentTest {
    
    public EstateAgentTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    // @Test
    // public void hello() {}
    
    @Test
    public void CalculateTotalSales_ReturnsTotalSales() {
        IEstateAgent estateAgent = new EstateAgent();
        double[] propertySales = {800000, 1500000, 2000000};
        double expectedTotalSales = 4300000; // Sum of the property sales

        double actualTotalSales = estateAgent.EstateAgentSales(propertySales);

        assertEquals(expectedTotalSales, actualTotalSales, 0.01); 
    }

    // Test case for CalculateTotalCommission method
    @Test
    public void CalculateTotalCommission_ReturnsCommission() {
        IEstateAgent estateAgent = new EstateAgent();
        double totalSales = 4300000; // Total sales from the previous test case
        double expectedCommission = 86000; // 2% of total sales

        double actualCommission = estateAgent.EstateAgentCommission(totalSales);

        assertEquals(expectedCommission, actualCommission, 0.01);
    }

    // Test case for TopAgent method
    @Test
    public void TopAgent_ReturnsTopPosition() {
        IEstateAgent estateAgent = new EstateAgent();
        double[] totalSales = {4300000, 3500000}; // Total sales for two estate agents
        int expectedTopAgentIndex = 0; 

        int actualTopAgentIndex = estateAgent.TopEstateAgent(totalSales);

        assertEquals(expectedTopAgentIndex, actualTopAgentIndex);
    }
}  
    
    
   




