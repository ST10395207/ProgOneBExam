/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package progonebexam;

/**
 *
 * @author jaido
 */
public class ProgOneBExam {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
       
       //2d array
       double[][] propertySales = {
                {800000, 1500000, 2000000},
                {700000, 1200000, 1600000}
        };

        EstateAgent estateAgent = new EstateAgent();

        double[] totalSales = new double[propertySales.length];
        double[] totalCommission = new double[propertySales.length];
        
        //string for agents names
        String[] agentNames = {"Joe Bloggs", "Jane Doe"};
        
        System.out.println("ESTATE AGENTS SALES REPORT");         
        System.out.println("\n\t\tJAN\t\tFEB\t\tMAR");         
        System.out.println("----------------------------------------------------");         
        System.out.println("Joe Bloggs\tR 800000.0\tR 1500000.0\tR 2000000.0");         
        System.out.println("Jane Doe\tR 700000.0\tR 1200000.0\tR 1600000.0\n");
        
        //method for total sales and sales commission
        for (int i = 0; i < propertySales.length; i++) {
            totalSales[i] = estateAgent.EstateAgentSales(propertySales[i]);
            totalCommission[i] = estateAgent.EstateAgentCommission(totalSales[i]);

            System.out.println(agentNames[i] + " total property sales = R " + totalSales[i]);
            System.out.println(agentNames[i] + " sales commission = R " + totalCommission[i]);
            System.out.println();
        }
        
        //method for top performing agent
        int topAgentIndex = estateAgent.TopEstateAgent(totalSales);
        System.out.println("Top performing estate agent: " + agentNames[topAgentIndex]); 
    }

} 
        
    